package com.example.restaurantmenuyoutube

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MakeActivity : AppCompatActivity() {

    private var mPizzaItems = 0
    private var mBurgerItems = 0
    private var mSoftDrinkItems = 0
    private var mJuiceItems = 0
    private var mWaterItems = 0
    private var mIceCreamItems = 0

    private var units : ArrayList<Int> = ArrayList()

    private lateinit var mButtonPizzaUnit : Button
    private lateinit var mButtonBurgerUnit : Button
    private lateinit var mButtonSoftDrinkUnit : Button
    private lateinit var mButtonJuiceUnit : Button
    private lateinit var mButtonWaterUnit : Button
    private lateinit var mButtonIceCreamUnit : Button

    private fun isSelectedItems() : Boolean{
        return (mPizzaItems+mBurgerItems+mSoftDrinkItems+mJuiceItems+mWaterItems+mIceCreamItems) > 0
    }

    private fun onButtonFinishClick(){
        if( !isSelectedItems() ){
            Toast.makeText(this, "No selected item", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this@MakeActivity, ShowOrderActivity::class.java)
        intent.putExtra("EXTRA_TOTAL_ITEMS", (mPizzaItems+mBurgerItems+mSoftDrinkItems+mJuiceItems+mWaterItems+mIceCreamItems))

        units.clear()
        units.add(mPizzaItems)
        units.add(mBurgerItems)
        units.add(mSoftDrinkItems)
        units.add(mJuiceItems)
        units.add(mWaterItems)
        units.add(mIceCreamItems)
        intent.putExtra("key", units)



        startActivity(intent)
    }

    private fun onButtonResetClick(){
        mPizzaItems = 0
        showPizzaUnit()
        mBurgerItems = 0
        showBurgerUnit()
        mSoftDrinkItems = 0
        mButtonSoftDrinkUnit.text = mSoftDrinkItems.toString()
        mJuiceItems = 0
        mButtonJuiceUnit.text = mJuiceItems.toString()
        mWaterItems = 0
        mButtonWaterUnit.text = mWaterItems.toString()
        mIceCreamItems = 0
        mButtonIceCreamUnit.text = mIceCreamItems.toString()

        units.clear()


        Toast.makeText(this, "Reset done", Toast.LENGTH_SHORT).show()
    }

    private fun showPizzaUnit(){
        //val mButtonPizzaUnit : Button = findViewById(R.id.button_pizza_unit)
        mButtonPizzaUnit.text = mPizzaItems.toString()
    }

    private fun onButtonPizzaAddClick(){
        mPizzaItems++
        showPizzaUnit()
    }

    private fun onButtonPizzaRemoveClick(){
        mPizzaItems--
        if(mPizzaItems<0){
            mPizzaItems=0
        }
        showPizzaUnit()
    }

    private fun showBurgerUnit(){
        //val mButtonBurgerUnit : Button = findViewById(R.id.button_burger_unit)
        mButtonBurgerUnit.text = mBurgerItems.toString()
    }

    private fun onButtonBurgerUpdateValue(id: Int){
        when(id){
            R.id.button_burger -> mBurgerItems++
            R.id.button_burger_add -> mBurgerItems++
            R.id.button_burger_remove -> {
                mBurgerItems--
                if(mBurgerItems<0){
                    mBurgerItems=0
                }
            }
        }
        showBurgerUnit()
    }

    private fun showUnit(id: Int){
        when(id){
            R.id.button_soft_drink -> mButtonSoftDrinkUnit.text = mSoftDrinkItems.toString()
            R.id.button_soft_drink_add -> mButtonSoftDrinkUnit.text = mSoftDrinkItems.toString()
            R.id.button_soft_drink_remove -> mButtonSoftDrinkUnit.text = mSoftDrinkItems.toString()
            R.id.button_juice -> mButtonJuiceUnit.text = mJuiceItems.toString()
            R.id.button_juice_add -> mButtonJuiceUnit.text = mJuiceItems.toString()
            R.id.button_juice_remove -> mButtonJuiceUnit.text = mJuiceItems.toString()
            R.id.button_water -> mButtonWaterUnit.text = mWaterItems.toString()
            R.id.button_water_add -> mButtonWaterUnit.text = mWaterItems.toString()
            R.id.button_water_remove -> mButtonWaterUnit.text = mWaterItems.toString()
            R.id.button_ice_cream -> mButtonIceCreamUnit.text = mIceCreamItems.toString()
            R.id.button_ice_cream_add -> mButtonIceCreamUnit.text = mIceCreamItems.toString()
            R.id.button_ice_cream_remove -> mButtonIceCreamUnit.text = mIceCreamItems.toString()
        }
    }

    private fun onButtonUpdateValue(id: Int){
        when(id){
            R.id.button_soft_drink -> mSoftDrinkItems++
            R.id.button_soft_drink_add -> mSoftDrinkItems++
            R.id.button_soft_drink_remove -> {
                mSoftDrinkItems--
                if(mSoftDrinkItems<0){
                    mSoftDrinkItems=0
                }
            }
            R.id.button_juice -> mJuiceItems++
            R.id.button_juice_add -> mJuiceItems++
            R.id.button_juice_remove -> {
                mJuiceItems--
                if(mJuiceItems<0){
                    mJuiceItems=0
                }
            }
            R.id.button_water -> mWaterItems++
            R.id.button_water_add -> mWaterItems++
            R.id.button_water_remove -> {
                mWaterItems--
                if(mWaterItems<0){
                    mWaterItems=0
                }
            }
            R.id.button_ice_cream -> mIceCreamItems++
            R.id.button_ice_cream_add -> mIceCreamItems++
            R.id.button_ice_cream_remove -> {
                mIceCreamItems--
                if(mIceCreamItems<0){
                    mIceCreamItems=0
                }
            }
        }
        showUnit(id)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_make_request)

        val mButtonConfirm : Button = findViewById(R.id.button_confirm)
        mButtonConfirm.setOnClickListener { onButtonFinishClick() }

        val mButtonReset : Button = findViewById(R.id.button_reset)
        mButtonReset.setOnClickListener {  onButtonResetClick() }

        val mButtonPizzaAdd : Button = findViewById(R.id.button_pizza_add)
        mButtonPizzaAdd.setOnClickListener {  onButtonPizzaAddClick() }

        //mButtonPizza.setOnClickListener { view -> onButtonPizzaAddClick() }  //ok
        val mButtonPizza : Button = findViewById(R.id.button_pizza)
        mButtonPizza.setOnClickListener { onButtonPizzaAddClick() }

        mButtonPizzaUnit = findViewById(R.id.button_pizza_unit)

        val mButtonPizzaRemove : Button = findViewById(R.id.button_pizza_remove)
        mButtonPizzaRemove.setOnClickListener {  onButtonPizzaRemoveClick() }


        val mButtonBurger : Button = findViewById(R.id.button_burger)
        mButtonBurger.setOnClickListener { view -> onButtonBurgerUpdateValue(view.id) }

        val mButtonBurgerAdd : Button = findViewById(R.id.button_burger_add)
        mButtonBurgerAdd.setOnClickListener { view -> onButtonBurgerUpdateValue(view.id) }

        val mButtonBurgerRemove : Button = findViewById(R.id.button_burger_remove)
        mButtonBurgerRemove.setOnClickListener { view -> onButtonBurgerUpdateValue(view.id) }

        mButtonBurgerUnit = findViewById(R.id.button_burger_unit)


        val mButtonSoftDrink: Button = findViewById(R.id.button_soft_drink)
        mButtonSoftDrink.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        val mButtonSoftDrinkAdd: Button = findViewById(R.id.button_soft_drink_add)
        mButtonSoftDrinkAdd.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        val mButtonSoftDrinkRemove: Button = findViewById(R.id.button_soft_drink_remove)
        mButtonSoftDrinkRemove.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        mButtonSoftDrinkUnit = findViewById(R.id.button_soft_drink_unit)


        val mButtonJuice : Button = findViewById(R.id.button_juice)
        mButtonJuice.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        val mButtonJuiceAdd : Button = findViewById(R.id.button_juice_add)
        mButtonJuiceAdd.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        val mButtonJuiceRemove : Button = findViewById(R.id.button_juice_remove)
        mButtonJuiceRemove.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        mButtonJuiceUnit = findViewById(R.id.button_juice_unit)


        val mButtonWater : Button = findViewById(R.id.button_water)
        mButtonWater.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        val mButtonWaterAdd : Button = findViewById(R.id.button_water_add)
        mButtonWaterAdd.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        val mButtonWaterRemove : Button = findViewById(R.id.button_water_remove)
        mButtonWaterRemove.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        mButtonWaterUnit = findViewById(R.id.button_water_unit)


        val mButtonIceCream : Button = findViewById(R.id.button_ice_cream)
        mButtonIceCream.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        val mButtonIceCreamAdd : Button = findViewById(R.id.button_ice_cream_add)
        mButtonIceCreamAdd.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        val mButtonIceCreamRemove : Button = findViewById(R.id.button_ice_cream_remove)
        mButtonIceCreamRemove.setOnClickListener { view -> onButtonUpdateValue(view.id) }

        mButtonIceCreamUnit = findViewById(R.id.button_ice_cream_unit)

    }

}