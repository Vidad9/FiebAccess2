package com.example.restaurantmenuyoutube

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class ShowOrderActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_order)

        var intent = intent

        val totalItems = intent.getIntExtra("EXTRA_TOTAL_ITEMS", 0)
        val mTextHello : TextView = findViewById(R.id.text_hello)
        mTextHello.text = "Total de items $totalItems"

        val mTextUnits : TextView = findViewById(R.id.text_units)
        val unitsList = intent.getSerializableExtra("key")
        mTextUnits.text = unitsList.toString()

    }
}