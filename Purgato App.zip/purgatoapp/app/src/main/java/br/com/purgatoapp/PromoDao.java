package br.com.purgatoapp;

// 2

import android.content.Context;
import android.util.Log;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PromoDao {

    private static final String TAG = "PromoDao";

    public static int insertPromo(Promo mPromo, Context mContext){

        int vResponse = 0;
        String mSql;

        try{
            mSql = "INSERT Promocao (nome, descricao, preco, data_validade) VALUES (?, ?, ?, ?)";

            PreparedStatement mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);

            mPreparedStatement.setString(1, mPromo.getNome());
            mPreparedStatement.setString(2, mPromo.getDescricao());
            mPreparedStatement.setDouble(3, mPromo.getPreco());
            mPreparedStatement.setDate(4, mPromo.getDataValidade());

            vResponse = mPreparedStatement.executeUpdate(); // executou com sucesso será 1

        }catch (Exception mException){
            Log.e(TAG, mException.getMessage());
            mException.printStackTrace();
        }

        return vResponse;

    }

    public static int updatePromo(Promo mPromo, Context mContext){

        int vResponse = 0;
        String mSql;

        try{
            mSql = "UPDATE Promocao SET nome=?, descricao=?, preco=? , data_validade=? WHERE id=?";
            PreparedStatement mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);

            mPreparedStatement.setString(1, mPromo.getNome());
            mPreparedStatement.setString(2, mPromo.getDescricao());
            mPreparedStatement.setDouble(3, mPromo.getPreco());
            mPreparedStatement.setDate(4, mPromo.getDataValidade());

            mPreparedStatement.setInt(5, mPromo.getId());
            vResponse = mPreparedStatement.executeUpdate(); // executou com sucesso será 1

        }catch (Exception mException){
            Log.e(TAG, mException.getMessage());
            mException.printStackTrace();
        }

        return vResponse;

    }

    public static int deletePromo(Promo mPromo, Context mContext){

        int vResponse = 0;
        String mSql;

        try{
            mSql = "Delete from Promocao where id=?";
            PreparedStatement mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);
            mPreparedStatement.setInt(1, mPromo.getId());
            vResponse = mPreparedStatement.executeUpdate();

        }catch(Exception mException){
            Log.e(TAG, mException.getMessage());
            mException.printStackTrace();
        }

        return vResponse;

    }

    public static int deleteAllPromocao(Context mContext){

        int vResponse = 0;
        String mSql;

        try{
            mSql = "Delete from Promocao";
            PreparedStatement mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);
            vResponse = mPreparedStatement.executeUpdate();

        }catch(Exception mException){
            Log.e(TAG, mException.getMessage());
            mException.printStackTrace();
        }

        return vResponse;

    }

    public static List<Promo> listAllPromocao(Context mContext){

        // Listagem de produtos
        List<Promo> mPromoList = null;
        String mSql;

        try{
            mSql = "Select id, nome, descricao, preco, data_validade from Promocao order by data_validade DESC";
            PreparedStatement mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);
            ResultSet mResultSet = mPreparedStatement.executeQuery();
            mPromoList = new ArrayList<Promo>();
            while(mResultSet.next()){
                mPromoList.add(new Promo(
                        mResultSet.getInt(1),
                        mResultSet.getString(2),
                        mResultSet.getDouble(3), // price
                        mResultSet.getString(4), //rating
                        mResultSet.getDate(5)
                ));
            }

        }catch(Exception mException){
            Log.e(TAG, mException.getMessage());
            mException.printStackTrace();
        }

        return mPromoList;

    }

 }

