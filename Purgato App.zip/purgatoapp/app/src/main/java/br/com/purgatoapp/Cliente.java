package br.com.purgatoapp;

public class Cliente {

   public static final String TAG = "Cliente do App";

    public Cliente(String email, String senha) {
        mEmail = email;
        mSenha = senha;
    }

    private int mId;

    public Cliente(String nome, String cpf, String email, String senha, String telefone) {
        mNome = nome;
        mCpf = cpf;
        mEmail = email;
        mSenha = senha;
        mTelefone = telefone;
    }

    public Cliente(int id, String nome, String cpf, String email, String senha, String telefone) {
        mId = id;
        mNome = nome;
        mCpf = cpf;
        mEmail = email;
        mSenha = senha;
        mTelefone = telefone;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public String getNome() {
        return mNome;
    }

    public void setNome(String nome) {
        mNome = nome;
    }

    public String getCpf() {
        return mCpf;
    }

    public void setCpf(String cpf) {
        mCpf = cpf;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getSenha() {
        return mSenha;
    }

    public void setSenha(String senha) {
        mSenha = senha;
    }

    public String getTelefone() {
        return mTelefone;
    }

    public void setTelefone(String telefone) {
        mTelefone = telefone;
    }

    private String mNome;
    private String mCpf;

    @Override
    public String toString() {
        return "Cliente{" +
                "mId=" + mId +
                ", mNome='" + mNome + '\'' +
                ", mCpf='" + mCpf + '\'' +
                ", mEmail='" + mEmail + '\'' +
                ", mSenha='" + mSenha + '\'' +
                ", mTelefone='" + mTelefone + '\'' +
                '}';
    }

    private String mEmail;
    private String mSenha;
    private String mTelefone;

}
