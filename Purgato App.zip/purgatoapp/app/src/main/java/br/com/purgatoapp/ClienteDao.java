package br.com.purgatoapp;

import android.content.Context;
import android.util.Log;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ClienteDao {




    private static final String TAG = "Cliente do App Dao";

    public static int insertCliente(Cliente mCliente, Context mContext){

        int vResponse = 0;
        String mSql;

        try{
            mSql = "Insert into ClienteS (nome , cpf, telefone, email, senha) values (?, ?, ?, ?, ?)";
            PreparedStatement mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);
            mPreparedStatement.setString(1, mCliente.getNome());
            mPreparedStatement.setString(2, mCliente.getCpf());
            mPreparedStatement.setString(3, mCliente.getTelefone());
            mPreparedStatement.setString(4, mCliente.getEmail());
            mPreparedStatement.setString(4, mCliente.getSenha());
            vResponse = mPreparedStatement.executeUpdate(); // executou com sucesso será 1

        }catch (Exception mException){
            Log.e(TAG, mException.getMessage());
            mException.printStackTrace();
        }

        return vResponse;

    }

    public static String authenticateCliente(Cliente mCliente, Context mContext){
        String mResponse = "";
        String mSql;
        try{

            //https://alvinalexander.com/blog/post/jdbc/jdbc-preparedstatement-select-like/

            mSql = "SELECT id, email, senha, nome FROM Clientes WHERE senha like ? and email like ?";

            //https://pt.stackoverflow.com/questions/369624/statement-ou-preparedstatement-por-qual-motivo-evitar-usar-o-statement

            PreparedStatement mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);

            mPreparedStatement.setString(1, mCliente.getSenha());
            mPreparedStatement.setString(2, mCliente.getEmail());
            ResultSet mResultSet = mPreparedStatement.executeQuery();
            while(mResultSet.next()){
                mResponse = mResultSet.getString(4); // veja o objeto 'mSql'
            }

        } catch(Exception mException){
            mResponse = "Exception";
            Log.e(TAG, mException.getMessage());
            mException.printStackTrace();
        }

        return mResponse;
    }


    public static int deleteProduct(Cliente mClientes, Context mContext){

        int vResponse = 0;
        String mSql;

        try{
            mSql = "Delete from Clientes where id=?";
            PreparedStatement mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);
            mPreparedStatement.setInt(1, mClientes.getId());
            vResponse = mPreparedStatement.executeUpdate();

        }catch(Exception mException){
            Log.e(TAG, mException.getMessage());
            mException.printStackTrace();
        }

        return vResponse;

    }


    public static int updateCliente(Cliente mCliente , Context mContext){

        // SERVE PARA ATUALIZAR A SENHA

        int vResponse = 0;
        // 0 representa NAO inseriu        1 inseriu com sucesso

        String mSql;

        try {
            //nome , cpf, telefone, email, senha
            mSql = "UPDATE Clientes SET nome=? , cpf=? , telefone=?, email=? , senha=? WHERE id=?";

            // preparar a troca dos parametros ?s (sete) pelo nome dos membros da classe User
            PreparedStatement  mPreparedStatement = MSSQLConnectionHelper.getConnection(mContext).prepareStatement(mSql);
            // associar as colunas
            mPreparedStatement.setString(1 , mCliente.getNome() );
            mPreparedStatement.setString(2 , mCliente.getCpf() );
            mPreparedStatement.setString(3 , mCliente.getTelefone() );
            mPreparedStatement.setString(4 , mCliente.getEmail() );
            mPreparedStatement.setString(5 , mCliente.getSenha() );

            mPreparedStatement.setInt(5 , mCliente.getId() );

            vResponse = mPreparedStatement.executeUpdate();


        } catch (Exception e){
            Log.e(TAG , e.getMessage()) ;
        }

        return vResponse;

    }


}
