package br.com.purgatoapp;

// 3

import android.content.Context;
import android.graphics.Color;
import android.speech.SpeechRecognizer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PromoAdapter extends RecyclerView.Adapter<PromoAdapter.PromoViewHolder> implements Filterable {

    // nv remove private final LayoutInflater mLayoutInflater;
    private View.OnClickListener mOnItemClickListener;
    private View.OnLongClickListener mOnLongClickListener;

    private Context mContext;
    private List<Promo> mPromoList;

    private TextView mTextViewTotalPrice;//nv2



//    public PromoAdapter(Context context, List<Promo> PromoList) { //nv
    public PromoAdapter(Context context, List<Promo> PromoList, TextView textViewTotalPrice) { //nv2
        mContext = context;
        mPromoList = PromoList;
        mTextViewTotalPrice = textViewTotalPrice;//nv2
    }

    private List<Promo> mPromoListFull; // será usada para recompor totalmente a lista na busca

//    public PromoAdapter(Context mContext){ //nv remove
//        mLayoutInflater = LayoutInflater.from(mContext);
//    }

    public String setPriceColor(double vRating){
        if(vRating < 3){
            return "#BF0404"; //299E4A green     737373 gray
        } else {
            return "#000000";
        }
    }

 //x1  public class PromoViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {
   public class PromoViewHolder extends RecyclerView.ViewHolder {
        // widgets do layout card_item_list.xml
        private final TextView mTextViewItemPromoImage;
        private final TextView mTextViewItemPromoNome;
        private final TextView mTextViewItemPromoPreco;

        private final TextView mTextViewDataValidade;
        private final TextView mTextViewItemPromoDescricao;
       //  private final RatingBar mRatingBarItemPromo;
       // private final Button mButtonPromoQuantity;
       //private final Button mButtonPromoAdd;
       // private final Button mButtonPromoRemove;

       // private final ImageView mImageViewPromo;

     double vTotalPrice = 0.0;



     int vQuantity = 0;
//     public class ClickMyButtonQuantity implements View.OnClickListener{
//         @Override
//         public void onClick(View view) {
//             vQuantity++;
//             mButtonPromoQuantity.setText(""+vQuantity);
//         }
//     }


     private void showTotalLavagens(){
         vTotalPrice = 0;
//         for (int i = 0; i <= mPromoList.size()-1; i++){
//             vTotalPrice = vTotalPrice + mPromoList.get(i).getPrice()* mPromoList.get(i).getUnit();
//         }
         NumberFormat mFormatValue = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
         String mStringValue = mFormatValue.format(vTotalPrice);
         mTextViewTotalPrice.setText(mStringValue);
     }



     private PromoViewHolder(@NonNull View itemView) {
            super(itemView);

            mTextViewItemPromoImage = itemView.findViewById(R.id.image);

            mTextViewItemPromoNome = itemView.findViewById(R.id.nome_da_promo);

            mTextViewItemPromoPreco = itemView.findViewById(R.id.preco);


            mTextViewItemPromoDescricao = itemView.findViewById(R.id.descricao_promo);

            mTextViewDataValidade = itemView.findViewById(R.id.data_validade);




//            itemView.setTag(this);
//            itemView.setOnClickListener(mOnItemClickListener);
//
        }


    }

    @NonNull
    @Override  // esse método carrega um item da lista
    public PromoViewHolder onCreateViewHolder(@NonNull ViewGroup mViewGroupParent, int viewType) {
        LayoutInflater mLayoutInflater = LayoutInflater.from(mContext);
        View mItemView = mLayoutInflater.inflate(R.layout.card_promotion, mViewGroupParent, false);
        return new PromoViewHolder(mItemView);
    }




    @Override        // vinculo dos objetos da tela com o objeto do java
    public void onBindViewHolder(@NonNull PromoViewHolder mPromoViewHolder, int vPosition) {
        Promo mPromoCurrent = mPromoList.get(vPosition);
        mPromoViewHolder.mTextViewItemPromoNome.setText(mPromoCurrent.getNome());

        // https://pt.stackoverflow.com/questions/30701/formata%C3%A7%C3%A3o-de-um-double-em-java
        // https://pt.stackoverflow.com/questions/219211/qual-a-forma-correta-de-usar-os-tipos-float-double-e-decimal
        // https://github.com/maniero/SOpt/blob/master/Conceptual.md  MARCOS DIVULGUE PARA OS ALUNOS

//        mPromoViewHolder.mTextViewItemPromoPrice.setText(String.valueOf(mPromoCurrent.getPrice()));
        String mStringPreco = String.format("%.2f", mPromoCurrent.getPreco());
        mPromoViewHolder.mTextViewItemPromoPreco.setText(mStringPreco);

      String mDataValidade = mPromoCurrent.getDataValidade().toString();
        SimpleDateFormat mDataPadraoFormatacao = new SimpleDateFormat("yyyy-MM-dd");
        Date d = null;
       try {
           d = mDataPadraoFormatacao.parse(mDataValidade);
        } catch (ParseException e) {
            throw new RuntimeException(e);
       }
        SimpleDateFormat mDataAplicarFormato = new SimpleDateFormat("dd MM yyyy");
       String mDataParaExibir = mDataAplicarFormato.format(d);
       mPromoViewHolder.mTextViewDataValidade.setText(mDataParaExibir);

       mPromoViewHolder.mTextViewItemPromoDescricao.setText(mPromoCurrent.getDescricao());


//        String mStringDataValidade = String.format("", mPromoCurrent.getDataValidade());
//        mPromoViewHolder.mTextViewDataValidade.setText(mStringDataValidade);


       // mPromoViewHolder.mTextViewItemPromoPrice.setTextColor(Color.parseColor(setPriceColor(mPromoCurrent.getRating())));
       // mPromoViewHolder.mRatingBarItemPromo.setRating(mPromoCurrent.getRating());

        //mPromoViewHolder.mButtonPromoQuantity.setText(""+mPromoCurrent.getUnit());

        // veja aqui PromoViewHolder - resposta de muitos erros
 //deveria ser aqui       mPromoViewHolder.mButtonPromoQuantity.setText(""+vQuantity);

        //mPromoViewHolder.mImageViewPromo.setImageDrawable(mContext.getResources().getDrawable(mPromoCurrent.getImage()));

        //Glide.with().load()    imagem - pesquise

    }

    @Override
    public int getItemCount() {
        if(mPromoList != null){
            return  mPromoList.size();
        } else {
            return 0;
        }
    }

    public void setPromoList(List<Promo> mPromos){
        mPromoList = mPromos;
        mPromoListFull = new ArrayList<>(mPromos);
        notifyDataSetChanged();
    }

    public Promo getPromoAt(int vPosition){
        return mPromoList.get(vPosition);
    }

    public void setOnItemClickListener(View.OnClickListener mItemClickListener){
        mOnItemClickListener = mItemClickListener;
    }

    public void setOnLongClickListener(View.OnLongClickListener mItemLongClickListener){
        mOnLongClickListener = mItemLongClickListener;
    }

    private Filter applyPromoFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<Promo> mFilteredList = new ArrayList<>();
            if(charSequence == null  ||  charSequence.length() == 0 ) {
                mFilteredList.addAll(mPromoListFull);
            } else {
                String mFilterPattern = charSequence.toString().toLowerCase().trim();
                for(Promo mPromo : mPromoListFull ) {
                    if(mPromo.getNome().toLowerCase().contains(mFilterPattern)){
                        mFilteredList.add(mPromo);
                    }
                }
            }
            FilterResults mFilterResults = new FilterResults();
            mFilterResults.values = mFilteredList;
            return mFilterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            mPromoList.clear();
            mPromoList.addAll((List) filterResults.values);
            notifyDataSetChanged();
        }
    };

    @Override
    public Filter getFilter(){
        return applyPromoFilter;
    }

}
