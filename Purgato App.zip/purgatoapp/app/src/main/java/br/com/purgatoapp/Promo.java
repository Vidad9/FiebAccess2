package br.com.purgatoapp;

import java.sql.Date;

public class Promo {

        private int mId;

    public Promo(String mNome, double vPreco, int i, String vDescricao, int i1, int vCycle, int vFrequency, int i2) {

    }

    public Promo(int vId, String mNome, double vPreco, int i, String vDescricao, int i1, int vCycle, int vFrequency, int i2) {
    }

    public int getId() {
        return mId;
    }

    public Promo(int mId, String mNome, Double mPreco, String mDescricao, Date mDataValidade) {
        this.mId = mId;
        this.mNome = mNome;
        this.mPreco = mPreco;
        this.mDescricao = mDescricao;
        this.mDataValidade = mDataValidade;
    }

    public Promo(String mNome, Double mPreco, String mDescricao, Date mDataValidade) {
        this.mNome = mNome;
        this.mPreco = mPreco;
        this.mDescricao = mDescricao;
        this.mDataValidade = mDataValidade;
    }

    @Override
    public String toString() {
        return "Promo{" +
                "mId=" + mId +
                ", mNome='" + mNome + '\'' +
                ", mPreco=" + mPreco +
                ", mDescricao='" + mDescricao + '\'' +
                ", mDataValidade=" + mDataValidade +
                '}';
    }

    public void setId(int mId) {
        this.mId = mId;
    }

    public String getNome() {
        return mNome;
    }

    public void setNome(String mNome) {
        this.mNome = mNome;
    }

    public Double getPreco() {
        return mPreco;
    }

    public void setPreco(Double mPreco) {
        this.mPreco = mPreco;
    }

    public String getDescricao() {
        return mDescricao;
    }

    public void setDescricao(String mDescricao) {
        this.mDescricao = mDescricao;
    }

    public Date getDataValidade() {
        return mDataValidade;
    }

    public void setDataValidade(Date mDataValidade) {
        this.mDataValidade = mDataValidade;
    }

    private String mNome;
        private Double mPreco;
        private String mDescricao;
        private Date mDataValidade;






    }

























