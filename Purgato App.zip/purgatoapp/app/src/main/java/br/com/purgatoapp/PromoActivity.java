package br.com.purgatoapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class PromoActivity extends AppCompatActivity {

    public static final String TAG = "List Promo Activity";

    public String TEXT_SEARCH = "my text search";

    public PromoAdapter mPromoAdapter;

    TextView mTextViewFullName, mTextViewTotalValue;

    FloatingActionButton mFabAdd;

    SharedPreferences mSharedPreferences;

        ActivityResultLauncher<Intent> mActivityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if(result.getResultCode() == RESULT_OK && result.getData() != null  ){
                                Bundle mBundleResponse = result.getData().getExtras();

                                int vId = mBundleResponse.getInt("EXTRA_ID" , -1);

                                String mNome = mBundleResponse.getString("EXTRA_NOME");

                                double Preco = mBundleResponse.getFloat("EXTRA_PRECO" , 0.0f);

                               /* String vDescricao= mBundleResponse.getInt("EXTRA_DESCRICAO" , 0);

                                int vCycle = mBundleResponse.getInt("EXTRA_CYCLE" , 0);

                                int vFrequency = mBundleResponse.getInt("EXTRA_FREQUENCY" , 0);

*/
                                String mMessage = "Create R Update D";
                                String mMode = mBundleResponse.getString("EXTRA_MODE");

                                if(mMode.equals("EDIT")){
//                                    Promo mPromo = new Promo(vId , mNome , vPreco , 1 , vDescricao, 0 , vCycle , vFrequency , 0);
                                    Promo mPromo = new Promo(vId , mNome , 0 , 1 , "", 0 , 0 , 0 , 0);
                                    int vResult = PromoDao.updatePromo(mPromo , getApplicationContext());
                                   if( vResult <= 0 ){
                                        mMessage = "Ocorreu um erro ao atulizar dados do produto";
                                    } else {
                                        setupRecyclerViewAdapter();
                                        mMessage = "Atualizado os dados do produto com sucesso";
                                    }


                                } else {
                                    Promo mPromo = new Promo( mNome , 0 , 1 , "" , 0 , 0 , 0 , 0);
                                    int vResult = PromoDao.insertPromo(mPromo , getApplicationContext());
                                    if( vResult <= 0 ){
                                        mMessage = "Ocorreu um erro ao inserir dados do novo produto";
                                    } else {
                                        setupRecyclerViewAdapter();
                                        mMessage = "Atualizado os dados do novo produto com sucesso";
                                    }
                                }
                                mTextViewTotalValue.setText("R$ 0.00");
                                Toast.makeText(PromoActivity.this , mMessage , Toast.LENGTH_SHORT).show();


                            } else if(result.getResultCode() == RESULT_CANCELED) {
                                Toast.makeText(PromoActivity.this, "Cancelado" , Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(PromoActivity.this, "Erro desconhecido", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

            );


    private View.OnClickListener onItemClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            RecyclerView.ViewHolder mViewHolder = (RecyclerView.ViewHolder) v.getTag();

        }
    };


    private void setupRecyclerViewAdapter() {
        RecyclerView mRecyclerView = findViewById(R.id.recyclerView_Promos);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        mRecyclerView.setHasFixedSize(true);

        mPromoAdapter = new PromoAdapter(getApplicationContext() ,
                PromoDao.listAllPromocao(getApplicationContext()) ,
                mTextViewTotalValue );

        mRecyclerView.setAdapter(mPromoAdapter);

        mPromoAdapter.setPromoList(PromoDao.listAllPromocao(getApplicationContext()));
        //mPromoAdapter.setOnItemClickListener(onItemClickListener);


    }


    // metodo para verificar se usuario nao logado
    // se não estiver logado - direcionar para a tela de login
    //                logado - apresentar o nome do usuario

    private void verifyNotLogged(){
        if( mSharedPreferences.getString("logged" , "false").equals("false") ){
            showLogin();
        } else {
            mTextViewFullName.setText(mSharedPreferences.getString("fullName", ""));
            setupRecyclerViewAdapter();
        }

    }

    private void showLogin() {
        // esse metodo inicia a proxima tela
        Intent mIntent = new Intent(getApplicationContext() , LoginActivity.class);
        startActivity(mIntent);
        finish();

    }


    // metodo para resetar/zerar os dados que estao compartilhados
    // isso é necessario para fazer o LOGOFF do app
    private void exitAppLogoff(){
        SharedPreferences.Editor mEditor = mSharedPreferences.edit();
        mEditor.putString("logged" , "");
        mEditor.putString("email" , "");
        mEditor.putString("fullName" , "");
        mEditor.apply();
        showLogin();

    }

    // definir um escutador usando um classe para fazer o logoff
    public class ClickMyButtonLogoff implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            exitAppLogoff();
        }
    }


    // metodo para apresentar a tela de ADD (digitacao) novo produto
    private void showAddPromo(){
        Intent mIntent = new Intent(getApplicationContext() , PromoActivity.class);
        mActivityResultLauncher.launch(mIntent);
    }

    // classe para escutar o click no botao de add um novo produto
    public class ClickMyButtonAddPromo implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            showAddPromo();
        }
    }


    // metodo para finalizar o pedido dos itens selecionados para a compra
    private void finalizePromoListToBuy(){
        // lógica para enviar ao banco de dados

    }


    // classe para definir um escutador(ouvinte) para o clique no botao finalizar
    // compra dos itens (esse botao nao é o checkout de uma compra e nem
    // o carrinho de compra)
    public class ClickMyButtonFinalizeListToBuy implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            finalizePromoListToBuy();
        }
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //oncreate representa a inicializacao da tela

        setContentView(R.layout.activity_promo);

        Intent mIntent = getIntent();
//        mTextViewFullName = findViewById(R.id.textView_fullName);

        if(mIntent.hasExtra("EXTRA_FULL_NAME")){
            mTextViewFullName.setText(mIntent.getStringExtra("EXTRA_FULL_NAME"));
        }

        // inicializar os objetos java com os elementos do layout

//        mFabAdd = findViewById(R.id.fab_add_Promo);
        mFabAdd.setOnClickListener(new ClickMyButtonAddPromo());

//        mTextViewTotalValue = findViewById(R.id.textView_total_value);

        mSharedPreferences = getSharedPreferences("MyAppName" , MODE_PRIVATE);
        verifyNotLogged();

    }


    // metodos para utilizar o menu ...
    // esse tipo de menu possui entre 3 até 5 itens para o usuario
    // clicar e executar uma ação especifica
    // o menu buscar (representado pela lupa) também é feito aqui


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
      //programar a acao do item selecionado no menu
        switch (item.getItemId()) {
//            case R.id.action_add:
//                showAddPromo();
//                return true;
//            case R.id.action_delete_all:
//                PromoDao.deleteAllPromo(getApplicationContext());
//                return true;
            default:
                return super.onOptionsItemSelected(item);


        }


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

//        MenuInflater mMenuInflater = getMenuInflater();
//        mMenuInflater.inflate(R.menu.main_menu , menu);
//
//        // gerenciar a busca - lupa
//        SearchManager mSearchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
//
//        // objeto para trabalhar com a busca
//        SearchView mSearchView = (SearchView) menu.findItem(R.id.action_main_menu_search).getActionView();
//        mSearchView.setSearchableInfo(mSearchManager.getSearchableInfo(getComponentName()));
//
//        // definir o escutador = ouvinte  para a digitacao que
//        // sera feita na busca
//        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//                TEXT_SEARCH = query;
//                return false;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//                mPromoAdapter.getFilter().filter(newText);
//                return false;
//            }
//        });


        return true;
    }
}
