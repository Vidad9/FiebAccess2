package br.com.purgatoapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class RegisterActivity extends AppCompatActivity {

    private static final String TAG = "SignUpActivity";

    private EditText mEditTextUser; //mEditTextFullName
    private EditText mEditTextEmail;

    private EditText mEditTextTelephone; // mEditTextUserName

    private EditText mEditTextPasswordRegister, mEditTextPasswordRegister2;

    private Button mButtonRegister;
   // private TextView mTextViewAlreadyLogin;
   // private ProgressBar mProgressBar;

    String mStringTelephone, mStringEmail, mStringPassword, mStringUser;

    private boolean isRequired(){
        if(TextUtils.isEmpty(mEditTextUser.getText()) || TextUtils.isEmpty(mEditTextEmail.getText()) ||  TextUtils.isEmpty(mEditTextTelephone.getText()) || TextUtils.isEmpty(mEditTextPasswordRegister.getText()) || TextUtils.isEmpty(mEditTextPasswordRegister2.getText())) {
            return true;
        } else {
            return false;
        }
    }

    private boolean isSamePassword(){
        String mPassword1 = mEditTextPasswordRegister.getText().toString();
        String mPassword2 = mEditTextPasswordRegister2.getText().toString();
        return mPassword1.equals(mPassword2);
    }

    private void performActivityLogin(){
        Intent mIntent = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(mIntent);
        finish();
    }

    private void postData(){
        if(isRequired()){
            String mTextMessage = getString(R.string.text_error_all_fields_required);
            Toast.makeText(getApplicationContext(), mTextMessage, Toast.LENGTH_SHORT).show();
            return;
        }

        if(!isSamePassword()){
            String mTextMessage = getString(R.string.text_password_are_not_same);
            Toast.makeText(getApplicationContext(), mTextMessage, Toast.LENGTH_SHORT).show();
            return;
        }

        mStringTelephone = String.valueOf(mEditTextTelephone.getText()).toLowerCase(Locale.ROOT);
        mStringEmail = String.valueOf(mEditTextEmail.getText());
        mStringPassword = String.valueOf(mEditTextPasswordRegister.getText());
        mStringUser = String.valueOf(mEditTextUser.getText());

      //  mProgressBar.setVisibility(View.VISIBLE);

        User mUser = new User(mStringUser, mStringTelephone, mStringPassword, mStringEmail, 0, "post", "otp", System.currentTimeMillis() );

        int vResult = UserDao.insertUser(mUser, getApplicationContext());

        String mTextMessage;

        mButtonRegister.setVisibility(View.GONE); //aluna Karen 3F dois clique no botao

        if(vResult <= 0){
            mTextMessage = getString(R.string.text_insert_error);
        } else {
            mTextMessage = getString(R.string.text_insert_success);
        }

       // mProgressBar.setVisibility(View.GONE);

       // Toast.makeText(getApplicationContext(), mTextMessage, Toast.LENGTH_SHORT).show();

       // Intent mIntent = new Intent(getApplicationContext(), LoginActivity.class);
       // startActivity(mIntent);
       // finish();

    }

    public class ClickButtonSignUp implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            postData();
        }
    }

    public class ClickTextViewAlreadyLogin implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            performActivityLogin();
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        mEditTextUser = findViewById(R.id.editText_user);
        mEditTextEmail = findViewById(R.id.editText_email);
        mEditTextTelephone= findViewById(R.id.editText_telephone);
        mEditTextPasswordRegister = findViewById(R.id.editText_password_register);
        mEditTextPasswordRegister2 = findViewById(R.id.editText_password_register_2);

       // mTextViewAlreadyLogin = findViewById(R.id.textView_already);
       // mTextViewAlreadyLogin.setOnClickListener(new ClickTextViewAlreadyLogin());

       // mProgressBar = findViewById(R.id.progressBarSignUp);

        mButtonRegister = findViewById(R.id.button_register);
        mButtonRegister.setOnClickListener(new ClickButtonSignUp());

    }
}
